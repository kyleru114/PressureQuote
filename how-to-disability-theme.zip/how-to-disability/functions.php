<?php
/**
 * HowToDisability functions and definitions
 *
 * @package HowToDisability
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Theme setup
 */
function howtodisability_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );
    
    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );
    
    // Enable support for Post Thumbnails
    add_theme_support( 'post-thumbnails' );
    
    // Add theme support for selective refresh for widgets
    add_theme_support( 'customize-selective-refresh-widgets' );
    
    // Add support for core custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ) );
    
    // Register navigation menus
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'howtodisability' ),
        'footer'  => esc_html__( 'Footer Menu', 'howtodisability' ),
    ) );
    
    // Switch default core markup to output valid HTML5
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );
    
    // Add support for Block Styles
    add_theme_support( 'wp-block-styles' );
    
    // Add support for responsive embedded content
    add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'howtodisability_setup' );

/**
 * Register widget area
 */
function howtodisability_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'howtodisability' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'howtodisability' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Widget Area', 'howtodisability' ),
        'id'            => 'footer-widgets',
        'description'   => esc_html__( 'Add footer widgets here.', 'howtodisability' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer-widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'howtodisability_widgets_init' );

/**
 * Enqueue scripts and styles
 */
function howtodisability_scripts() {
    // Theme stylesheet
    wp_enqueue_style( 'howtodisability-style', get_stylesheet_uri(), array(), '1.0.0' );
    
    // Custom JavaScript
    wp_enqueue_script( 'howtodisability-script', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true );
    
    // Comment reply script
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'howtodisability_scripts' );

/**
 * Custom excerpt length
 */
function howtodisability_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'howtodisability_excerpt_length', 999 );

/**
 * Custom excerpt more
 */
function howtodisability_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'howtodisability_excerpt_more' );

/**
 * Default menu fallback
 */
function howtodisability_default_menu() {
    ?>
    <ul id="primary-menu" class="menu">
        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
        <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a></li>
        <li><a href="<?php echo esc_url( home_url( '/resources' ) ); ?>">Resources</a></li>
        <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Blog</a></li>
        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
    </ul>
    <?php
}

/**
 * Customizer additions
 */
// require get_template_directory() . '/inc/customizer.php';

/**
 * Social sharing buttons
 */
function howtodisability_social_share() {
    global $post;
    
    if ( is_singular( 'post' ) ) {
        $url = get_permalink();
        $title = get_the_title();
        ?>
        <div class="social-share">
            <span>Share this post:</span>
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( $url ); ?>" 
               class="social-share-button share-facebook" 
               target="_blank" 
               rel="noopener noreferrer">
                Facebook
            </a>
            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode( $url ); ?>&text=<?php echo urlencode( $title ); ?>" 
               class="social-share-button share-twitter" 
               target="_blank" 
               rel="noopener noreferrer">
                Twitter
            </a>
            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode( $url ); ?>&title=<?php echo urlencode( $title ); ?>" 
               class="social-share-button share-linkedin" 
               target="_blank" 
               rel="noopener noreferrer">
                LinkedIn
            </a>
        </div>
        <?php
    }
}

/**
 * Add Open Graph meta tags for better social sharing
 */
function howtodisability_add_opengraph_tags() {
    if ( is_single() ) {
        global $post;
        ?>
        <meta property="og:title" content="<?php echo esc_attr( get_the_title() ); ?>" />
        <meta property="og:description" content="<?php echo esc_attr( get_the_excerpt() ); ?>" />
        <meta property="og:url" content="<?php echo esc_url( get_permalink() ); ?>" />
        <meta property="og:type" content="article" />
        <?php if ( has_post_thumbnail() ) : ?>
            <meta property="og:image" content="<?php echo esc_url( get_the_post_thumbnail_url( $post->ID, 'large' ) ); ?>" />
        <?php endif; ?>
        <meta property="og:site_name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
        <?php
    }
}
add_action( 'wp_head', 'howtodisability_add_opengraph_tags' );

/**
 * Custom post meta function
 */
function howtodisability_posted_on() {
    $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
    if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
        $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
    }

    $time_string = sprintf(
        $time_string,
        esc_attr( get_the_date( DATE_W3C ) ),
        esc_html( get_the_date() ),
        esc_attr( get_the_modified_date( DATE_W3C ) ),
        esc_html( get_the_modified_date() )
    );

    $posted_on = sprintf(
        /* translators: %s: post date. */
        esc_html_x( 'Posted on %s', 'post date', 'howtodisability' ),
        '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
    );

    echo '<span class="posted-on">' . $posted_on . '</span>';
}

/**
 * Add custom image sizes
 */
function howtodisability_add_image_sizes() {
    add_image_size( 'blog-thumbnail', 400, 300, true );
    add_image_size( 'featured-large', 1200, 600, true );
}
add_action( 'after_setup_theme', 'howtodisability_add_image_sizes' );

/**
 * Disable emoji scripts for better performance
 */
function howtodisability_disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'howtodisability_disable_emojis' );

/**
 * SEO improvements - Add schema markup
 */
function howtodisability_schema_type() {
    $schema = 'https://schema.org/';
    
    if ( is_single() ) {
        $type = "Article";
    } elseif ( is_author() ) {
        $type = 'ProfilePage';
    } elseif ( is_search() ) {
        $type = 'SearchResultsPage';
    } else {
        $type = 'WebPage';
    }
    
    echo 'itemscope itemtype="' . esc_url( $schema . $type ) . '"';
}