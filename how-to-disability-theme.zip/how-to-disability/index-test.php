<?php get_header(); ?><h1>Theme is working!</h1><?php get_footer(); ?>
